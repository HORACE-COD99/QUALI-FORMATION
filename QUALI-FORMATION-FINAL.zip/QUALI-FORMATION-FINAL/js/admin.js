document.getElementById('admin-login-form').addEventListener('submit', function(e) {
    e.preventDefault();
    if (validateForm('admin-login-form')) {
        // Redirection si mot de passe correct
        window.location.href = "dashboard.html";
    }
});