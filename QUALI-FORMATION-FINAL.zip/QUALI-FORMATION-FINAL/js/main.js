// Vérifie si tous les champs requis sont remplis
function validateForm(formId) {
    const form = document.getElementById(formId);
    const inputs = form.querySelectorAll('[required]');
    
    let isValid = true;
    inputs.forEach(input => {
        if (!input.value) {
            input.classList.add('error');
            isValid = false;
        }
    });
    return isValid;
}